export { profile } from "./profile";
export { projects } from "./projects";
export { certificates } from "./certificates";
export { research } from "./research";