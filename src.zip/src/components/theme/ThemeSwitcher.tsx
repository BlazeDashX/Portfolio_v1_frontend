"use client";

import { useTheme } from "./ThemeProvider";

export default function ThemeSwitcher() {
  const { style, mode, setStyle, setMode } = useTheme();

  return (
    <div className="flex items-center gap-2 text-xs">
      <button
        onClick={() => setStyle(style === "cyber" ? "clean" : "cyber")}
        className="rounded-lg border px-3 py-2"
        title="Toggle style"
      >
        Style: {style}
      </button>

      <button
        onClick={() => setMode(mode === "dark" ? "light" : "dark")}
        className="rounded-lg border px-3 py-2"
        title="Toggle mode"
      >
        Mode: {mode}
      </button>
    </div>
  );
}