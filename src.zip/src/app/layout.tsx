import "./globals.css";
import type { Metadata } from "next";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { ThemeProvider } from "@/components/theme/ThemeProvider";
import CursorGlow from "@/components/ui/CursorGlow";

export const metadata: Metadata = {
  title: "Refat — Portfolio",
  description: "CSE Student • Web Dev • CV/ML Learner",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <ThemeProvider>
          <div className="cyber-bg" />
          <CursorGlow />

          <Navbar />

          {/* This fixes “text starts from edge” globally */}
          <main className="pt-20">
            <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
              {children}
            </div>
          </main>

          <Footer />
        </ThemeProvider>
      </body>
    </html>
  );
}