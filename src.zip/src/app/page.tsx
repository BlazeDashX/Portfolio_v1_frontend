"use client";

import { motion } from "framer-motion";
import MagneticButton from "@/components/MagneticButton";
import dynamic from "next/dynamic";
import ProjectCard from "@/components/project/ProjectCard";
import GitHubStats from "@/components/github/GitHubStats";
import { projects } from "@/data";import Container from "@/components/ui/Container";

const ProfileTilt = dynamic(() => import("@/components/ProfileTilt"), { ssr: false });

export default function HomePage() {
  const featuredSlugs = ["e-commerce-engine", "task-orchestrator", "portfolio-v2"];
  const featured = projects.filter((p) => featuredSlugs.includes(p.slug));

  return (
    <>
      {/* === HOME PAGE BACKGROUND (THEME-AWARE) === */}
      <div className="fixed inset-0 -z-10 pointer-events-none opacity-30 bg-noise" />

      <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
        {/* accent glow */}
        <div
          className="absolute -top-40 left-1/2 h-[620px] w-[980px] -translate-x-1/2 rounded-full blur-[130px]"
          style={{ background: "color-mix(in srgb, var(--accent) 18%, transparent)" }}
        />
        {/* secondary glow */}
        <div
          className="absolute bottom-[-220px] right-[-220px] h-[560px] w-[560px] rounded-full blur-[120px]"
          style={{ background: "color-mix(in srgb, var(--accent2) 14%, transparent)" }}
        />
      </div>
      {/* ========================================= */}

      <div className="space-y-16">
        {/* HERO */}
        <section className="pt-8">
          <div className="grid grid-cols-1 lg:grid-cols-[1.2fr_.8fr] gap-10 items-center">
            <div>
              <motion.div
                initial={{ opacity: 0, y: 18, filter: "blur(10px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="inline-flex items-center gap-3 rounded-full border border-soft bg-card px-4 py-2 text-xs text-muted"
              >
                <span className="h-2 w-2 rounded-full cyber-glow" style={{ background: "var(--accent)" }} />
                CSE Student • Web Dev • CV/ML Learner
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 28 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.9, ease: "easeOut", delay: 0.05 }}
                className="mt-6 text-6xl sm:text-7xl font-semibold tracking-tight"
              >
                <span className="text-main">Ref</span>
                <span className="text-accent">at</span>
                <span className="text-muted">.</span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.75, ease: "easeOut", delay: 0.12 }}
                className="mt-4 text-lg text-muted max-w-xl"
              >
                I build robust systems and craft high-performance web apps — currently exploring
                Computer Vision and deep learning.
              </motion.p>

              <div className="mt-8 flex flex-wrap gap-3">
                <MagneticButton href="/projects" variant="solid">
                  View Projects
                </MagneticButton>
                <MagneticButton href="/contact" variant="ghost">
                  Contact Me
                </MagneticButton>
              </div>

              {/* status */}
              <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-xl">
                {[
                  { k: "Build", v: "Web Systems" },
                  { k: "Stack", v: "Next + TS" },
                  { k: "Research", v: "CV/ML" },
                  { k: "Focus", v: "Quality" },
                ].map((x, idx) => (
                  <div key={x.k} className="rounded-2xl border border-soft bg-card px-4 py-3">
                    <div className="text-xs text-muted">{x.k}</div>
                    <div className="mt-1 text-sm text-main">{x.v}</div>
                    <div className="mt-2 h-1 rounded bg-card overflow-hidden">
                      <div
                        className="h-full"
                        style={{
                          width: `${[82, 76, 64, 88][idx]}%`,
                          background: "linear-gradient(90deg, var(--accent), var(--accent2))",
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <motion.div
              initial={{ opacity: 0, scale: 0.92 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.9, ease: "easeOut", delay: 0.08 }}
              className="flex justify-center lg:justify-end"
            >
              <ProfileTilt />
            </motion.div>
          </div>
        </section>

        {/* GITHUB */}
        <section className="space-y-4">
          <div className="flex items-end justify-between gap-4">
            <h2 className="text-3xl font-semibold tracking-tight text-main">GitHub</h2>
            <a
              className="text-sm text-accent hover:opacity-80 transition"
              href="https://github.com/BlazeDashX"
              target="_blank"
              rel="noreferrer"
            >
              View profile →
            </a>
          </div>
          <GitHubStats />
        </section>

        {/* FEATURED */}
        <section>
          <div className="flex items-end justify-between gap-4">
            <h2 className="text-3xl font-semibold tracking-tight text-main">Featured Work</h2>
            <a className="text-sm text-accent hover:opacity-80 transition" href="/projects">
              View all →
            </a>
          </div>

          <div className="mt-7 grid grid-cols-1 md:grid-cols-3 gap-5">
            {featured.map((p) => (
              <ProjectCard key={p.slug} project={p} />
            ))}
          </div>
        </section>
      </div>
    </>
  );
  
}